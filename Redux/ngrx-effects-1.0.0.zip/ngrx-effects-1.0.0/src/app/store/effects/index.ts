import { UsuariosEffects } from './usuarios.effects';
import { UsuarioEffects } from './usuario.effects';





export const EffectsArray: any[] = [ UsuariosEffects, UsuarioEffects ];
